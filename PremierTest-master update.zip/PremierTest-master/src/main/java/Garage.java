/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */



/**
 *
 * @author 2417127
 */
public class Garage {

    public static void main(String[] args) {
        
    }
}
